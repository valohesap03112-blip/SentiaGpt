# Sentia

Çoklu model (Claude + GPT + Gemini) sohbet arayüzü.

## Render'a Deploy

1. Bu klasörü GitHub'a yükle.
2. Render'da **New Web Service** oluştur.
3. GitHub repo'yu bağla.
4. Ayarlar:
   - **Build Command**: `npm install`
   - **Start Command**: `node server.js`
   - **Root Directory**: boş bırak (veya `sentia-server` ise onu yaz)
5. Deploy et.

## Lokal Çalıştırma

```bash
npm install
npm start
```

Tarayıcıda: http://localhost:3000

## Önemli

- API anahtarlarını Ayarlar’dan gir (sadece tarayıcıda saklanır).
- `node_modules` klasörünü asla repo’ya yükleme.
- `package.json` içinde `express` bağımlılığı olmalı.
